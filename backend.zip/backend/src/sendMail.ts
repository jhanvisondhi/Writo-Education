const nodeMailer = require("nodemailer");
import {Response} from "express"

const mailSender = async (detail; any, res: Response) => {
  try {
       
    const transporter = nodeMailer.createTransport({
      host: "smtp.zoho.in",
      port: 465,
      secure: true,
      auth: {
        user: "sender-email",
        pass: "app-password",
      },
    });

    const options = {
      from: `"myApp" <sender-Email>`,
      to: `${detail.email}`,
      subject: "Please find your otp below:-",
      text: `${detail.otp}`,
    };

    const sentMail = await transporter.sendMail(options);

    if (sentMail.response === "250 Message received") {
    return res
      .status(200)
      .json({ msg: "member created successfully", sentMail });
    }

    return res.status(200).json({ msg: "member created successfully" });

    
  } catch (error) {
    return res.status(500).json({ msg: error });
  }
};

module.exports = mailSender;
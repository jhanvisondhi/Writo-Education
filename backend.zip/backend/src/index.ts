import express, { Request, Response } from "express";
import cors from "cors";
import bodyParser from "body-parser";
import mongoose from "mongoose";
import userModel from "../src/models/User";
const { v4 } = require("uuid");

const app = express();
const PORT = process.env.PORT || 5000;
const uri =
  "mongodb+srv://sondhijhanvi68:RflXUAr7w486ekKl@cluster0.fy6cq.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";
const mail = require("./sendMail");

mongoose
  .connect(uri, { dbName: "Signin" })
  .then((e) => console.log("DB Connected"))
  .catch((err) => {
    throw err;
  });

app.use(cors());
app.use(bodyParser.json());

//user login api
app.post("/api/login", async (req: Request, res: Response) => {
  const user = await userModel.findOne({ email: req.body.email });

  if (user?.isFirstLogin) {
    if (user?.otp == req.body.password) {
      await userModel.updateOne({ isFirstLogin: false });
      return res.status(200).json({ msg: "success", user });
    } else {
      return res.status(400).json({ msg: "invalid otp please try again" });
    }
  } else if (user?.password === req.body.password) {
    return res.status(200).json({ msg: "success", user });
  }

  return res.status(400).json({ msg: "invalid user or password" });
});

//user signup api
app.post("/api/signup", async (req: Request, res: Response) => {
  try {
    const random = v4();
    const data = await userModel.create({ ...req.body, otp: random });

    if (!data) {
      return res.status(500).json({ msg: "failed to create user" });
    }

    await mail({ email: data.email, otp: data.otp }, res);
  } catch (e) {
    console.log(e);
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
